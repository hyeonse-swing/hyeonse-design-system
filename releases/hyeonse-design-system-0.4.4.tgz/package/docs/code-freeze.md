# 코드 프리즈 기준

코드 프리즈는 아래 검사로 확인한 패키지와 공개 API의 변경을 멈추는 시점이다. `v0.4.0` 패키지 아카이브에는 기존 CSS·폼 컴포넌트·화면 설정·CLI뿐 아니라 `layout`, `fields`, `overlays`, `display`도 포함한다. WebKit 검사에는 Base UI의 VoiceOver 초점 가드에 대한 `aria-command-name` 미해결 항목이 있어 접근성 프리즈 완료로 기록하지 않는다. 이전 베이스라인의 axe 39건 결과는 새 컴포넌트의 접근성 통과 근거가 아니다.

## 반복 가능한 검사

```sh
npm ci
npx --no-install playwright install chromium firefox webkit
npm run verify:freeze
npm audit
npm pack --dry-run
git diff --check
```

Linux CI에서는 `playwright install --with-deps`로 필요한 시스템 라이브러리까지 설치한다. `verify:freeze`는 다음 두 단계를 순서대로 실행한다.

| 명령 | 확인 범위 |
|---|---|
| `npm run verify` | 소스·예제·쇼케이스·브라우저 소비 예제 타입 검사, 패키지·쇼케이스 빌드, Node 회귀 테스트 |
| `npm run verify:browser` | 설치한 Playwright Chromium·Firefox·WebKit에서 같은 동작·접근성 검사 |

브라우저 결과와 실패 화면은 `output/browser/`에 저장한다. 결과에는 실제 검사에 사용한 빌드·소비 예제·검사 코드의 SHA256, Node·OS·도구·브라우저 버전, axe 위반과 자동 판정 불가(`incomplete`) 항목이 포함된다. `incomplete`는 통과한 규칙으로 세지 않으며 별도로 검토한다. 특정 엔진만 재현하려면 빌드 후 `npm run verify:browser -- firefox`처럼 실행한다. 한 번의 실패를 재실행 성공만으로 해결했다고 판단하지 않는다.

## 고정할 계약

- `package.json`의 exports와 공개 선언, 카탈로그, CLI 출력이 같은 버전을 가리킨다. 카탈로그와 `llms*`는 생성 결과로 유지한다.
- `Button`의 기본 type은 `button`이다. 로딩 중 활성화를 막고 `loadingLabel`을 접근 가능한 이름으로 제공한다.
- 입력의 외부 `id`, `ref`, 네이티브 폼 동작을 보존한다. 설명·오류의 내부 ID가 다른 입력의 ID와 충돌하지 않는다. `Checkbox`의 읽기 전용 상태는 폼 값에 포함되고 비활성 상태는 제외된다.
- 확장 필드의 제어형·비제어형 값, 폼 제출, 레이블·오류 연결을 확인한다. 네이티브 `DateField`는 달력 조합이나 범위 선택을 제공하지 않는다.
- 오버레이의 열림 상태, 키보드·초점 복귀, 비동기 확인과 오류 전달, 토스트 Provider 범위를 확인한다. `display`의 Table은 의미 있는 표이며 데이터 그리드 동작을 제공하지 않는다.
- 같은 문서와 저장 키를 사용하는 설정 Provider들은 최신 상태를 공유한다. 같은 키의 Provider와 초기 스크립트에는 같은 기본값을 사용한다. 서로 다른 키는 같은 문서의 테마를 독립적으로 소유하지 않는다.
- 저장소 접근이 차단되어도 현재 탭의 설정을 바꿀 수 있다. 다른 탭, 기기 테마·움직임 감소, 새로고침 복원을 확인한다.
- CSS 감사는 잘못된 설정이나 CSS 0개 탐색을 성공으로 처리하지 않는다. 소비 루트 밖의 경로·심볼릭 링크를 검사 범위에 섞지 않고 중복 경로를 한 번만 센다. 정확한 경로 정책은 [CSS 감사 문서](audit.md)를 따른다.

## 브라우저 검사 범위

현재 실행기는 다음 시나리오를 각 브라우저에서 실행한다. 새 컴포넌트의 조합 검사는 `scripts/browser-suites.mjs`에 있으며 실행 결과는 실제 `verify:browser` 출력으로 확인한다.

1. 쇼케이스: 본문 건너뛰기, 키보드 버튼·체크박스, 폼 오류·성공, 토큰·API 검색, 복사 성공·실패 UI. 복사는 테스트 대역으로 콜백을 검증하며 운영체제 클립보드 권한을 검증하지 않는다.
2. 독립 소비 예제: 전역 CSS reset 없는 네이티브 폼, 이름·설명 연결, ID 충돌, submit/reset, 읽기 전용·비활성, 로딩 이름.
3. 소비 예제 접근성: 동일한 원본 마크업을 별도의 새 브라우저 context에서 열어 axe 전체 규칙 검사.
4. 표시 설정: 1440·390px × 밝음·어두움 × 세 강조색, 총 12조합의 넘침·axe 검사. 움직임 감소, 320px 리플로우, 글자 간격 확대도 확인한다. 표시 설정 UI의 조작 요소는 기존 최소 44px을 유지한다.
5. 설정 동기화: 같은 키의 두 React root, 두 탭, 새로고침, 기기 설정 변경.
6. 저장소 차단: 읽기·쓰기가 실패할 때의 설정 변경과 관련 없는 storage 이벤트.
7. JavaScript 비활성: 문서 읽기, 앵커 이동, API 상세 펼치기와 좁은 화면.
8. 확장 입력: 선택·검색·다중 선택·라디오·스위치·숫자·슬라이더·날짜·파일·비밀번호 입력과 FormData, 초기화.
9. 오버레이: 메뉴·하위 메뉴·우클릭 메뉴, Dialog/Sheet 내부의 선택 목록과 팝오버, 키보드 초점·복귀, 확인/취소, 툴팁, F6 토스트 이동과 닫기.
10. 탐색·표시: 탭 방향키·Home, 아코디언·접기, 페이지 이동·선택 상태, 표·진행률·아바타 의미 구조.
11. 초점 가드: 선택·검색·다중 선택·메뉴·모달·중첩 선택·토스트의 각 가드에 초점을 주어 1초 안에 보이고 접근 가능한 실제 요소로 이동하는지 검사한다.
12. 검색 목록 닫힘: 단일·다중 검색과 Sheet 내부 검색에서 Tab·Shift+Tab·바깥 클릭 시 목록이 닫히고 일시적으로 숨긴 배경의 접근성과 초점이 복구되는지 확인한다.
13. 확장 접근성: 세 컴포넌트 그룹의 1440·390px × 밝음·어두움 조합, 펼친 선택·메뉴·Dialog·AlertDialog·Sheet·Popover·토스트, 중첩 선택 목록. 넘침·axe·화면 캡처를 남긴다.

axe는 WCAG 2·2.1 A/AA 태그의 자동 규칙을 사용한다. `incomplete` 중 선택 표시의 체크 기호는 계산 색상 대비 3:1, 가로 스크롤 메뉴는 투명 배경을 포함한 조상 배경 추적으로 글자 대비 4.5:1을 추가 검사한다. 펼친 팝업과 겹쳐 자동 판단이 불가능한 필드·대화상자 문구·트리거는 불투명 배경과 조상 투명도를 확인한 뒤 4.5:1 대비를 계산한다. `aria-controls` 자동 판단 불가 항목은 실제 ID의 유일성, popup 역할과 표시 상태를 확인한다. 확장 컨트롤의 장식 아이콘도 3:1 대비를 확인하고, 아이콘 전용 링크·버튼은 장식 요소와 접근 가능한 이름을 확인한다. 원래 `incomplete` 결과와 추가 검사 결과를 모두 남기며, 추가 검사로 해결하지 못한 항목이 생기면 실패한다. axe가 숨긴 초점 가드에 보고하는 `aria-hidden-focus`는 원문을 보존하고, 같은 엔진에서 선행한 가드별 초점 이동 검사를 근거로 별도 판정한다. 가드가 아닌 요소는 이 예외를 받지 않는다. 모달 배경의 `focusable-modal-open` 항목은 각 모달에서 Tab·Shift+Tab 각 10회 초점 유지 검사가 선행된 경우에만 별도 판정한다. Combobox가 목록 밖을 임시로 숨기는 항목은 열기 전의 숨김 상태를 기록하고, 같은 엔진의 단일·다중·중첩 검색 닫힘 검사를 근거로 구분한다. 기존에 숨겨져 있던 요소에는 적용하지 않는다. 이는 [W3C ACT 6cfa84의 통과 예제 4](https://www.w3.org/WAI/standards-guidelines/act/rules/6cfa84/#passed-example-4)에 근거하며, axe 원문 위반 건수를 0으로 바꾸지 않는다. 기준은 W3C의 [텍스트 대비](https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html)와 [비텍스트 대비](https://www.w3.org/WAI/WCAG22/Understanding/non-text-contrast.html)를 따른다. 스크린리더의 실제 읽기 순서·안내, 모든 보조 기술, 실기기 키보드·터치 조작을 증명하지 않는다. macOS WebKit의 링크 이동은 Safari의 기본 키보드 설정에 맞춰 Option-Tab으로 확인한다.

Firefox의 소비 예제와 확장 입력 화면에서는 axe와 Playwright 역할·접근 가능한 이름 조회를 같은 문서에서 이어 실행할 때 content process 충돌이 재현됐다. 소비 예제는 새 문서의 axe 검사와 별도 문서의 전체 상호작용 검사로 분리했다. 확장 접근성 검사에서는 CSS·표시 텍스트로 실제 컨트롤을 조작하고, 역할·이름·키보드 계약은 별도 동작 시나리오에서 검사한다. 마크업과 모든 axe 규칙은 유지한다. 엔진 내부 원인은 확정하지 않았으며, 이 분리는 로딩 전환 중의 axe 검사를 증명하지 않는다. 전환 전후 이름·비활성·활성화 동작은 별도 브라우저 assertion과 Node 회귀 테스트로 확인한다.

Base UI 1.9.0은 WebKit에서 VoiceOver 가상 커서의 초점 이동을 받기 위해 빈 초점 가드에 `role="button"`을 부여하고 `aria-hidden`을 제거한다. axe가 보고하는 이 요소의 `aria-command-name`은 미해결로 유지한다. 실행기는 나머지 동작 검사를 계속하되 해당 시나리오를 `REVIEW`, `pass: false`, `manualReviewRequired`로 기록하고 전체 종료 코드를 1로 반환한다. 일반 버튼의 이름 누락에는 이 분류를 적용하지 않는다. 가드에 DOM 초점을 주어 실제 요소로 이동한 결과는 VoiceOver의 읽기·가상 커서 검증을 대신하지 않는다. 가드가 없는 시나리오의 `guards: 0`도 가드 이동 성공으로 세지 않는다.

2026-11-17에 확인한 [상위 라이브러리 이슈 #5237](https://github.com/mui/base-ui/issues/5237)는 열려 있으며, 현재 최신 1.9.0의 공개 API에는 가드 이름이나 렌더링을 바꾸는 옵션이 없다. 실제 Safari의 접근성 트리에서도 이름 없는 가드가 노출됐다. VoiceOver를 켜서 추가 확인을 시도했으나 자동화 도구로 읽기 자막과 VoiceOver 명령의 결과를 관측하지 못해 실제 읽기 검증은 완료하지 않았다. 검사 후 VoiceOver는 원래의 꺼짐 상태로 복원했다. 이 결과를 근거로 검사 규칙을 제외하거나 포커스 가두기를 해제하지 않는다.

## 생성물·소비 앱·CI

- 같은 소스를 다시 빌드했을 때 `dist/`, `llms.txt`, `llms-full.txt`, 생성 글꼴과 글자 범위 파일이 달라지지 않아야 한다. CI는 추적 파일의 차이와 새 생성 파일을 모두 검사한다.
- 후보 패키지를 `npm pack`으로 만들고, 원본을 수정하지 않는 소비 앱 복사본에 설치한다. 포트폴리오는 `npm run verify`, Flow QA는 CSS·타입·UI 서버 테스트·패키지 소비 검사를 실행한다. v0.4.0의 Base UI 런타임 의존성을 패키지에 함께 묶는 소비 앱은 하위 의존성까지 배포 파일 허용 목록·라이선스 검사를 갱신해야 한다. Flow QA의 기존 허용 목록은 이 검사에 실패했으며, 2026-11-17 로컬 소비 앱 작업본에서 선언된 배포 의존성을 따라 검사하도록 수정했다. 검증용 HDS 0.4.0 포함 Flow QA tarball은 Git 없이 설치되고 CLI·UI 자산을 제공함을 확인했다. 원본 Flow QA의 HDS 참조 변경이나 공개 배포는 수행하지 않았다.
- CI는 Node.js 22·24 검사와 세 브라우저 작업을 분리해 실행한다. 워크플로 파일을 추가한 사실과 원격 CI 성공은 별도 증거다. 원격에 반영한 후에는 해당 커밋의 작업 결과를 확인한다.
- 프리즈 후 릴리스할 때에는 검증한 커밋, 태그, 배포 revision, 정식 도메인 연결을 기록한다. 로컬 통과만으로 운영 배포 완료를 기록하지 않는다.

실제 Safari, iOS·Android 실기기, VoiceOver·NVDA 등은 별도 검증 범위다. 프리즈 판단에는 검사 환경과 남은 제한을 함께 남긴다.


## 2026-11-17 사이징 검증 추가

`verify:freeze`는 타입·패키지·사이트 검증 후 `verify:sizing`과 기존 `verify:browser`를 실행한다. `verify:sizing`은 5단계 크기와 명시적 자식 재지정, 선택 목록·모달 포털, Grid 리플로우, compact 밀도, 터치 조작 영역을 Chromium·Firefox·WebKit에서 확인한다. 별도 크기 검사가 통과해도 기존 WebKit 초점 가드 접근성 미해결을 해소한 것으로 취급하지 않는다.

## v0.4.0 패키지 제공 방식

릴리스 대상은 `https://design-system.hyeonse.dev/releases/hyeonse-design-system-0.4.0.tgz`의 버전 고정 아카이브와 `/releases/manifest.json`이다. 매니페스트의 `name`, `version`, `file`, `url`, `sha256`, `integrity`, `size`를 실제 배포 파일과 비교한 뒤 공개 완료를 기록한다. 이 방식은 npm 레지스트리 게시나 GitHub `v0.4.0` 태그 발행이 아니다. 기존 GitHub `v0.3.0` 태그는 네 개 기본 컴포넌트의 이전 버전이다. WebKit의 [상위 라이브러리 이슈 #5237](https://github.com/mui/base-ui/issues/5237)가 남아 있으므로 패키지 제공과 접근성 프리즈 완료를 같은 상태로 기록하지 않는다.

## v0.4.3 네이티브 선택·모달 대안

0.4.2 기준 실제 WebKit 접근성 트리에서 열린 `Select` 가드 4개와 `Dialog` 가드 2개는 이름 없는 버튼으로 나타났고, 확장 접근성 검사의 Base UI `aria-command-name` 24건은 미해결이었다. Chromium·Firefox에서는 같은 가드가 접근성 트리에 노출되지 않았다. CSS 생성 문구는 WebKit 트리에 이름처럼 보였지만 axe는 여전히 가드를 이름 없는 버튼으로 판정했다. 상위 라이브러리 내부를 덮어쓰거나 검사 규칙을 제외하는 근거로 사용하지 않는다.

`NativeSelect`와 `NativeDialog`는 고정 선택과 일반 모달의 별도 공개 경로다. `<select>`와 `<dialog>.showModal()`을 사용하므로 이 둘만 조합한 화면에는 Base UI 가드가 생기지 않는다. WebKit의 네이티브 모달에서는 Tab이 문서 본문으로 빠지는 경우를 확인해, `NativeDialog`가 보이는 내부 조작 요소 사이의 Tab·Shift+Tab 이동을 직접 관리한다. Escape·닫기·바깥 클릭 뒤 초점 복귀도 검사한다. 네이티브 선택의 메뉴 모양과 일부 키 동작은 브라우저·OS에 맡긴다. 검색 목록·메뉴·시트·팝오버, 또는 이들을 `NativeDialog` 안에 둔 경우에는 기존 Base UI 가드가 남는다.

브라우저 검사의 `native-alternatives`는 네이티브 선택의 이름·값·폼 초기화, 모달 접근성 트리의 제목·필드 이름, axe 전체 규칙, Tab·Shift+Tab 각 10회, Escape·닫기·바깥 클릭·제어형 모달 닫힘과 초점 복귀를 Chromium·Firefox·WebKit에서 검사한다. 이 별도 시나리오의 통과는 기존 `expanded-accessibility`의 `REVIEW`를 통과로 바꾸지 않는다. 2026-11-18에 VoiceOver를 임시 실행해 로컬 Safari 창을 확인하려 했으나 AppleScript 자막 조회가 시간 초과되어 실제 발화와 가상 커서는 관측하지 못했다. 자체 창을 닫고 VoiceOver 실행 상태를 다시 꺼짐으로 확인했다. 실제 보조 기술 검증은 남은 조건이다.


## v0.4.4 폼·키보드 보완

제어형 `NativeSelect`는 현재 `value`에 해당하는 option의 `defaultSelected`를 함께 설정한다. 브라우저의 `form.reset()` 기본 동작이 그 값을 즉시 복원하므로 reset 직후 동기 `FormData`의 선택값도 제어 상태와 같다. 비제어형 선택과 취소된 reset의 브라우저 동작은 기존 규칙을 따른다.

`NativeDialog`는 macOS WebKit에서 Full Keyboard Access가 꺼져 있을 때 내부 버튼을 건너뛰어 잠시 문서 본문으로 초점이 나가는 경로를 처리한다. 계산한 다음 Tab 위치가 버튼이면 기본 이동 전에 그 버튼으로 초점을 옮긴다. 라디오 그룹·편집 영역·자식이 취소한 Tab 이동은 브라우저 조작을 유지한다.

2026-11-18 현재 `@base-ui/react`의 npm 최신 버전은 1.9.0이고, [초점 가드 이슈 #5237](https://github.com/mui/base-ui/issues/5237)는 열려 있다. 기존 24건의 WebKit 접근성 검사 결과는 해결된 것으로 기록하지 않는다.
